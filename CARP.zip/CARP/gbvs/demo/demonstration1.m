
% This file is a demonstration of how to call gbvs()

% make some parameters
params = makeGBVSParams;

% could change params like this
params.contrastwidth = .11;

% example of itti/koch saliency map call
params.useIttiKochInsteadOfGBVS = 0;
for i = 1 : 5
    filename1 = sprintf('E:/Documents and Settings/trailer/����/д����/gbvs1/gbvs/samplepics/%d.jpg',i);
    outitti = gbvs(filename1,params);
    imgi = outitti.master_map_resized;
    filename2 = sprintf('E:/Documents and Settings/trailer/����/д����/gbvs1/gbvs/demo/result/%dsaliency.jpg',i);
    imwrite(imgi, filename2 );
end