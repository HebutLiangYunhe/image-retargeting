% This file is a demonstration of how to call gbvs()

% make some parameters
params = makeGBVSParams;

% could change params like this
params.contrastwidth = .11;

% example of itti/koch saliency map call
params.useIttiKochInsteadOfGBVS = 0;
for i = 10 : 300
    filename1 = sprintf('E:/Documents and Settings/trailer/����/д����/BerkleyͼƬ��/%d.jpg',i);
    outitti = gbvs(filename1,params);
    imgi = outitti.master_map_resized;
    filename2 = sprintf('E:/Documents and Settings/trailer/����/д����/BerkleyͼƬ��/result10-99/%dsaliency.jpg',i);
    imwrite(imgi, filename2 );
end