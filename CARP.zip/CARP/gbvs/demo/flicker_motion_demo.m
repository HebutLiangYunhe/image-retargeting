
% some video sequence
i = 1;
for imgi = 397 : 407
    fname{i} = sprintf('E:/Documents and Settings/trailer/����/д����/BerkleyͼƬ��/motion test/image00%d.jpg',imgi);
    i = i + 1;
end
N = length(fname);

% compute the saliency maps for this sequence

param = makeGBVSParams; % get default GBVS params
param.channels = 'CIORFM'; % 'IF';  % but compute only 'I' instensity and 'F' flicker channels

                                  %   C is for Color
                                  %   I is for Intensity
                                  %   O is for Orientation
                                  %   R is for contRast
                                  %   F is for Flicker
                                  %   M is for Motion
                                  
pram.colorWeight = 1;                % weights of feature channels (do not need to sum to 1). 
pram.intensityWeight = 1;             
pram.orientationWeight = 1;
pram.contrastWeight = 1;
pram.flickerWeight = 3;
pram.motionWeight = 3;
pram.dklcolorWeight = 1;

param.levels = 3;       % reduce # of levels for speedup

motinfo = [];           % previous frame information, initialized to empty
for i = 1 : N
    [out{i} motinfo] = gbvs( fname{i}, param , motinfo );
end

% display results
figure;
for i = 1 : N
   subplot(2,N,i);    
   imshow( imread(fname{i}) );
   title( fname{i} );
  % subplot(2,N,N+i);
  % imshow( out{i}.master_map_resized);
   imgi = out{i}.master_map_resized; %.* 255 
  
   filename = sprintf('E:/Documents and Settings/trailer/����/д����/BerkleyͼƬ��/motion test/image00%dsaliency.jpg',i+396);
  %imgi = uint8(imgi);
  imwrite(imgi, filename);
end
